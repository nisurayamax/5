#!/bin/bash

#put reboot program call here