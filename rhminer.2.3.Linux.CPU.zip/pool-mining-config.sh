#!/bin/bash
while true
do
    ./rhminer -configfile config.txt
    sleep 5s
done




